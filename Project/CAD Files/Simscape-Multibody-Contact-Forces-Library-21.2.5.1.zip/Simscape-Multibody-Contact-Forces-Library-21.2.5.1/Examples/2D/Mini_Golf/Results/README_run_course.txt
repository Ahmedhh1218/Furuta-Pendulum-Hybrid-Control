Run MATLAB script Mini_Golf_Run_Course.m
That code will run each hole and save the path of the ball
on each hole to this folder as a MATLAB figure.

Copyright 2012-2022 The MathWorks(TM), Inc.