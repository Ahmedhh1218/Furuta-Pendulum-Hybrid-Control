% ADUSTMENTS WITH DEMO PUTTER ACTUATOR
% Copyright 2012-2021 The MathWorks(TM), Inc.

Mini_Golf_Param.Hole_1.Open_Loop_Adjustments = [20 3; -80 2; 0 2; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
Mini_Golf_Param.Hole_2.Open_Loop_Adjustments = [-30 2; 40 3; 0 2; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
Mini_Golf_Param.Hole_3.Open_Loop_Adjustments = [0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
Mini_Golf_Param.Hole_4.Open_Loop_Adjustments = [15 5; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
Mini_Golf_Param.Hole_5.Open_Loop_Adjustments = [-21 2; -21 2; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
Mini_Golf_Param.Hole_6.Open_Loop_Adjustments = [16 10;-50 1; 0 2; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
Mini_Golf_Param.Hole_7.Open_Loop_Adjustments = [10 9; 0 4; 35 5; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
Mini_Golf_Param.Hole_8.Open_Loop_Adjustments = [-40 6; 50 3; 40 3; 0 1; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
Mini_Golf_Param.Hole_9.Open_Loop_Adjustments = [5 10; -5 4; 0 2; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0];
